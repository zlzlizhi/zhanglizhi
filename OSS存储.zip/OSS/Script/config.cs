﻿/**
 *Copyright(C) 2015 by #COMPANY#
 *All rights reserved.
 *FileName:     #SCRIPTFULLNAME#
 *Author:       #AUTHOR#
 *Version:      #VERSION#
 *UnityVersion：#UNITYVERSION#
 *Date:         #DATE#
 *Description:   
 *History:
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class config 
{
    public const string AccessKeyId = "LTAI5tFLzNBssWjB3UiiwyqM";
    public const string AccessKeySecret = "XBaWhnLy89x3RXDXlSwj5x4MXopiJZ";
    public const string EndPoint = "oss-cn-beijing.aliyuncs.com";
    public const string Bucket = "fujianjh";
}
